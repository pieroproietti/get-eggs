# Alpine

It have the configuration for modules, take calamares_modules from buster