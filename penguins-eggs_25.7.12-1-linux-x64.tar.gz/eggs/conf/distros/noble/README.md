# Ubuntu 24.04 noble

It take all configuration from Ubuntu focal
