# Debian 9 stretch

It take all configuration of Debian buster
it use krill