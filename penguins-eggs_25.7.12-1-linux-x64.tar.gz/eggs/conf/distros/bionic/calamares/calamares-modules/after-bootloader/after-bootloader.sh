#"for i in `ls /home/`; do rm /home/$i/Desktop/install-system.desktop || exit 0; done"
