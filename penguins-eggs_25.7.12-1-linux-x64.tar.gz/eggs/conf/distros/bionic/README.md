# Ubuntu 18.04 bionic

It take all configuration of Debian buster

* grub from focal
* isolinux from focal

* /calamares/calamares-modules/add366arch original
* /calamares/calamares-modules/after-bootloader original
* /calamares/calamares-modules/before-bootloader original
* /calamares/calamares-modules/before-bootloader-mkdirs original
* /calamares/calamares-modules/bug original
* /calamares/calamares-modules/grubcfg original
* /calamares/calamares-modules/remove-link from buster
* /calamares/calamares-modules/sources-yolk from buster
* /calamares/calamares-modules/sources-yolk-undo from buster

* /calamares/modules/bootloader.yml original
* /calamares/modules/displaymanager.yml from focal
* /calamares/modules/finished.yml original
* /calamares/modules/fstab.yml original
* /calamares/modules/packages.yml from buster
* /calamares/modules/partition.yml original
* /calamares/modules/removeuser.yml from buster
* /calamares/modules/unpackfs.yml from buster
* /calamares/modules/users.yml original
* /calamares/modules/welcome.yml original

Used by:
* Linux Mint tricia 
* Zorin OS 
