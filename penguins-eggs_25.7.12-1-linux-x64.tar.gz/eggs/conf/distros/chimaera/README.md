# Devuan chimaera

It take all configuration of Debian buster