#!/usr/bin/env bash
xrandr --output Virtual-0 --auto > /dev/null
xrandr --output Virtual-1 --auto > /dev/null
xrandr --output Virtual-2 --auto > /dev/null
xrandr --output Virtual-2 --auto > /dev/null
